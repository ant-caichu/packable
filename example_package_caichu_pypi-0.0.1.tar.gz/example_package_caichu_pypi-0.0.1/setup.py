from setuptools import setup

setup(
   name='example_package_caichu_pypi',
   version='0.0.1',
   description='A useful module',
   author='Cai Chu',
   author_email='caichu.fh@antgroup.com',
   packages=['example_package'],  #same as name
   install_requires=['wheel', 'bar', 'greek'], #external packages as dependencies
)
